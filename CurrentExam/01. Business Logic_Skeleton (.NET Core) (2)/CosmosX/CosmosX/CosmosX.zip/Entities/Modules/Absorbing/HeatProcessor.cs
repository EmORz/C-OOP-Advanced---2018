﻿namespace CosmosX.Entities.Modules.Absorbing
{
    public class HeatProcessor : BaseAbsorbingModule
    {
        public HeatProcessor(int id, int heatAbsorbing)
            : base(id, heatAbsorbing)
        {
        }
    }
}