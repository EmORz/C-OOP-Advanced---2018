﻿using System;

namespace Database
{
    class Program
    {
        static void Main(string[] args)
        {
            ////int[] arr = new int[17];
            //Database data = new Database(arr);
        }
    }
}
