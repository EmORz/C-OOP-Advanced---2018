﻿namespace StorageMaster.Core.IO.Contracts
{
	public interface IReader
	{
		string ReadLine();
	}
}