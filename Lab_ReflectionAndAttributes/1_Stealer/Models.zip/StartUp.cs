﻿using System;
using _1_Stealer.Core;

namespace _1_Stealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
