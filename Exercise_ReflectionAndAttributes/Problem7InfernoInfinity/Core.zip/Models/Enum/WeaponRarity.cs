﻿namespace Problem7InfernoInfinity.Models.Enum
{
    public enum WeaponRarity
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
