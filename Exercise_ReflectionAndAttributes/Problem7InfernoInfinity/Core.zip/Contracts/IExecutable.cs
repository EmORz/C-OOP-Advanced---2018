﻿namespace Problem7InfernoInfinity.Contracts
{
    public interface IExecutable
    {
        void Execute();
    }
}
