﻿using System;
using System.Collections.Generic;
using System.Text;
using Problem7InfernoInfinity.Models.Enum;

namespace Problem7InfernoInfinity.Contracts
{
    public interface IQualitativeGem
    {
        GemClarity GemClarity { get; }
    }
}
