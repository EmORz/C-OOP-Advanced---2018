﻿namespace Problem7InfernoInfinity.Contracts
{
    public interface IGem
    {
        int Strenght { get; }

        int Agility { get; }

        int Vitality { get; }
    }
}