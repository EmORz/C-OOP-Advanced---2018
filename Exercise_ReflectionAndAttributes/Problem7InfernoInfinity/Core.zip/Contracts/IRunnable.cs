﻿namespace Problem7InfernoInfinity.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
