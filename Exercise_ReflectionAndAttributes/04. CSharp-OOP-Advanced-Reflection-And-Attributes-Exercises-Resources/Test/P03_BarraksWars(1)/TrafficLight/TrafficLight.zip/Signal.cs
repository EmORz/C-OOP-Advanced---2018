﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficLight
{
    public enum Signal
    {
        Red,
        Green,
        Yellow
    }
}
