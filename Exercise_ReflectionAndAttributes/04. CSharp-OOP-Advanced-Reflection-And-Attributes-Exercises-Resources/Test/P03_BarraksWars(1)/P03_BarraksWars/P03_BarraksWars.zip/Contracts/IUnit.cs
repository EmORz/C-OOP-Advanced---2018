﻿namespace _03BarracksFactory.Contracts
{
    public interface IUnit : IDestroyable, IAttacker
    {

    }
}
