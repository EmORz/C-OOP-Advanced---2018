﻿namespace CustomClassAttribute
{
    [Info("Pesho", "Used for C# OOP Advanced Course - Enumerations and Attributes.", 3, "Pesho", "Svetlio")]
    public abstract class Weapon
    {
    }
}
