﻿using Problem6TrafficLights.Core;

namespace Problem6TrafficLights
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
