﻿namespace Problem6TrafficLights.Enum
{
    public enum Signal
    {
        Red,
        Green,
        Yellow
    }
}
