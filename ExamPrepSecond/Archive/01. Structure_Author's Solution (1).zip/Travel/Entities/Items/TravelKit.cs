﻿namespace Travel.Entities.Items
{
	public class TravelKit : Item
	{
		public TravelKit()
			: base(value: 30)
		{
		}
	}
}