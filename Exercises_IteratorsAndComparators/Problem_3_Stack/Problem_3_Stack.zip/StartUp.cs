﻿using System;
using Problem_3_Stack.Core;

namespace Problem_3_Stack
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
