﻿namespace Problem_8_PetClinics
{
    using Core;

    public class StartUp
    {
        public static void Main(string[] args)
        {
           Engine engine = new Engine();
            engine.Run();
        }
    }
}
