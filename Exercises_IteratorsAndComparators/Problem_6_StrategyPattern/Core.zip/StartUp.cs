﻿namespace Problem_6_StrategyPattern
{
    using Problem_6_StrategyPattern.Core;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
