﻿using System;
using Problem_5_ComparingObjects.Core;

namespace Problem_5_ComparingObjects
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
