﻿using Problem_4_Froggy.Core;

namespace Problem_4_Froggy
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
